package exceptions;

public class HeightWrongOrderException extends Exception {
}
